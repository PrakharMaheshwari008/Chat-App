# ChatApp
A realtime time chat application that allow users to chat on a relatime (similar to Whatsapp..).
![Screenshot from 2022-07-07 18-59-38](https://user-images.githubusercontent.com/62890691/177787565-d4885718-25b5-4685-b5fb-213d05daf060.png)
